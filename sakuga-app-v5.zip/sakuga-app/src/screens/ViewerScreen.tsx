import React, { useState, useRef, useCallback } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView } from 'react-native';
import { useVideoPlayer, VideoView } from 'expo-video';
import { colors } from '../theme/colors';
import { isVideoFile } from '../api/sakugabooru';

// Same fps assumption as the bookmarklet: sakugabooru's post data doesn't
// expose a real frame rate, so this defaults to 24fps (standard for anime).
// Frame stepping is only as accurate as the player's own seek precision —
// same honest limitation as any browser-based approach, not something a
// native app magically fixes.
const DEFAULT_FPS = 24;
const MED_STEP = 10;

function formatTime(t: number) {
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  const sStr = s.toFixed(1).padStart(4, '0');
  return `${m}:${sStr}`;
}

export default function ViewerScreen({ route }: any) {
  const { post } = route.params;
  const playable = isVideoFile(post.file_url);
  const fps = Number(post.frame_rate) || DEFAULT_FPS;
  const bigStep = Math.max(1, Math.round(fps));

  const player = useVideoPlayer(playable ? post.file_url : null, (p) => {
    p.loop = false;
    // Scrubbing mode is expo-video's purpose-built optimization for exactly
    // this scenario — many frequent seeks in a short span — so frame steps
    // actually redraw immediately instead of needing a play/pause nudge hack.
    p.scrubbingModeOptions = { scrubbingModeEnabled: true };
  });

  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  // expo-video doesn't guarantee a fine-grained timeupdate event across
  // platforms, so this polls the player's own position — simple and reliable
  // rather than depending on an event name I can't verify without testing.
  // Some platforms suppress normal playback while scrubbing mode is left on
  // (documented Android behavior) — so it's toggled off while actually
  // playing, and back on whenever paused, ready for the next frame step.
  React.useEffect(() => {
    if (!playable) return;
    const sub = player.addListener('playingChange', (event) => {
      player.scrubbingModeOptions = { scrubbingModeEnabled: !event.isPlaying };
    });
    return () => sub.remove();
  }, [playable, player]);

  React.useEffect(() => {
    if (!playable) return;
    const interval = setInterval(() => {
      setCurrentTime(player.currentTime || 0);
      setDuration(player.duration || 0);
    }, 100);
    return () => clearInterval(interval);
  }, [playable, player]);

  const step = useCallback(
    (deltaFrames: number) => {
      player.pause();
      const next = currentTime + deltaFrames / fps;
      player.currentTime = Math.max(0, Math.min(duration || next, next));
    },
    [player, currentTime, duration, fps]
  );

  const frameCount = Math.round(currentTime * fps);
  const totalFrames = Math.round(duration * fps);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.headRow}>
        <Text style={styles.badge}>▲ {post.score}</Text>
        <Text style={styles.badge}>{post.rating}</Text>
        <Text style={styles.postId}>#{post.id}</Text>
      </View>

      {playable ? (
        <>
          <VideoView player={player} style={styles.video} nativeControls />

          <View style={styles.frameBar}>
            <View style={styles.frameRow}>
              <TouchableOpacity style={styles.frameBtn} onPress={() => step(-bigStep)}>
                <Text style={styles.frameBtnText}>«</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.frameBtn} onPress={() => step(-MED_STEP)}>
                <Text style={styles.frameBtnText}>‹‹</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.frameBtn} onPress={() => step(-1)}>
                <Text style={styles.frameBtnText}>‹</Text>
              </TouchableOpacity>
              <Text style={styles.frameCount}>
                {frameCount} / {totalFrames}
              </Text>
              <TouchableOpacity style={styles.frameBtn} onPress={() => step(1)}>
                <Text style={styles.frameBtnText}>›</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.frameBtn} onPress={() => step(MED_STEP)}>
                <Text style={styles.frameBtnText}>››</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.frameBtn} onPress={() => step(bigStep)}>
                <Text style={styles.frameBtnText}>»</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.frameTime}>
              {formatTime(currentTime)} / {formatTime(duration)}
            </Text>
          </View>
        </>
      ) : (
        <Image
          source={{ uri: post.sample_url || post.file_url }}
          style={styles.image}
          resizeMode="contain"
        />
      )}

      <Text style={styles.tags}>{post.tags}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  headRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 10,
    backgroundColor: colors.panel2,
  },
  badge: {
    backgroundColor: colors.bg,
    color: colors.amber,
    fontSize: 11,
    fontFamily: 'monospace',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
    overflow: 'hidden',
  },
  postId: { color: colors.dim, fontSize: 11, fontFamily: 'monospace', marginLeft: 'auto' },
  video: { width: '100%', aspectRatio: 16 / 9, backgroundColor: '#000' },
  image: { width: '100%', height: 300, backgroundColor: '#000' },
  frameBar: { padding: 10, backgroundColor: colors.panel2 },
  frameRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  frameBtn: {
    backgroundColor: colors.bg,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 5,
    paddingHorizontal: 10,
    paddingVertical: 7,
  },
  frameBtnText: { color: colors.text, fontSize: 14 },
  frameCount: {
    flex: 1,
    textAlign: 'center',
    color: colors.amber,
    fontWeight: 'bold',
    fontFamily: 'monospace',
    fontSize: 13,
  },
  frameTime: {
    textAlign: 'center',
    color: colors.dim,
    fontFamily: 'monospace',
    fontSize: 11,
    marginTop: 6,
  },
  tags: { color: colors.dim, fontSize: 11, padding: 16, lineHeight: 18 },
});

