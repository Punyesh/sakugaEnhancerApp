import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { FFmpegKit, ReturnCode } from '@spreen/ffmpeg-kit-react-native';

export interface TrimResult {
  uri: string;
  filename: string;
  seconds: number;
}

/** Trims a clip to [inTime, outTime]. `accurate` re-encodes (libx264, real
 * frame accuracy, slower) vs a fast stream-copy (near-instant, but can only
 * cut on the nearest keyframe) — same fast/accurate tradeoff and CRF choice
 * as the bookmarklet, after the same real feedback (frame-accurate seeking
 * needs -ss/-to placed after -i with real encoders, not -c copy). */
export async function performTrim(
  sourceUrl: string,
  postId: number,
  inTime: number,
  outTime: number,
  accurate: boolean,
  onStatus?: (status: string) => void
): Promise<TrimResult> {
  const startedAt = Date.now();
  onStatus?.('downloading clip…');

  const sourceExt = sourceUrl.split('.').pop()?.split('?')[0] || 'webm';
  const inputFile = new File(Paths.cache, `sakuga_${postId}_input.${sourceExt}`);
  try {
    inputFile.delete();
  } catch {
    // Fine if there was nothing to delete (no stale file from a prior attempt).
  }
  const downloaded = await File.downloadFileAsync(sourceUrl, inputFile, { idempotent: true });

  const outputExt = accurate ? 'mp4' : sourceExt;
  const outputFile = new File(Paths.cache, `sakuga_${postId}_trim.${outputExt}`);
  try {
    outputFile.delete();
  } catch {
    // Same as above.
  }

  onStatus?.(accurate ? 'trimming (re-encoding for frame accuracy)…' : 'trimming (fast mode)…');

  const command = accurate
    ? `-i "${downloaded.uri}" -ss ${inTime} -to ${outTime} -c:v libx264 -preset veryfast -crf 15 -c:a aac "${outputFile.uri}"`
    : `-ss ${inTime} -to ${outTime} -i "${downloaded.uri}" -c copy "${outputFile.uri}"`;

  const session = await FFmpegKit.execute(command);
  const returnCode = await session.getReturnCode();

  if (!ReturnCode.isSuccess(returnCode)) {
    const logs = await session.getOutput();
    throw new Error(`ffmpeg failed: ${(logs || '').slice(-400)}`);
  }

  return { uri: outputFile.uri, filename: outputFile.name, seconds: (Date.now() - startedAt) / 1000 };
}

export async function shareTrimResult(uri: string) {
  const available = await Sharing.isAvailableAsync();
  if (!available) throw new Error('sharing is not available on this device');
  await Sharing.shareAsync(uri);
}
