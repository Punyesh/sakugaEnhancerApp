import React, { useState, useCallback } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, ActivityIndicator } from 'react-native';
import { colors } from '../theme/colors';
import { searchTags, Tag } from '../api/sakugabooru';
import EmptyState from '../components/EmptyState';

export default function ShowSearchScreen({ navigation }: any) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Tag[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const search = useCallback(async () => {
    if (!query.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const tags = await searchTags(query, 3, 25); // type 3 = copyright/show tags
      setResults(tags);
    } catch (e: any) {
      setError(e.message || 'search failed');
    } finally {
      setLoading(false);
    }
  }, [query]);

  return (
    <View style={styles.container}>
      <View style={styles.row}>
        <TextInput
          style={styles.input}
          placeholder="search a show title"
          placeholderTextColor={colors.dim}
          value={query}
          onChangeText={setQuery}
          onSubmitEditing={search}
          returnKeyType="search"
          autoCapitalize="none"
        />
        <TouchableOpacity style={styles.searchBtn} onPress={search}>
          <Text style={styles.searchBtnText}>Search</Text>
        </TouchableOpacity>
      </View>

      {loading && <ActivityIndicator color={colors.amber} style={{ marginTop: 20 }} />}
      {error && <Text style={styles.error}>error: {error}</Text>}
      {!results && !loading && !error && (
        <EmptyState icon="📺" text="Search a show title to browse its episodes, openings, and endings." />
      )}

      {results && !loading && (
        <FlatList
          style={{ marginTop: 12 }}
          data={results}
          keyExtractor={(t) => t.name}
          ListEmptyComponent={<Text style={styles.empty}>no matching titles found</Text>}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.row2}
              onPress={() => navigation.navigate('ShowDetail', { showTag: item.name })}
            >
              <Text style={styles.showName}>{item.name}</Text>
              <Text style={styles.showCount}>{item.count}</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg, padding: 12 },
  row: { flexDirection: 'row', gap: 8 },
  input: {
    flex: 1,
    backgroundColor: colors.panel,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 6,
    color: colors.text,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  searchBtn: {
    backgroundColor: colors.amberDim,
    borderWidth: 1,
    borderColor: colors.amber,
    borderRadius: 6,
    paddingHorizontal: 14,
    justifyContent: 'center',
  },
  searchBtnText: { color: colors.amber, fontWeight: 'bold', fontSize: 12 },
  error: { color: colors.red, marginTop: 16, textAlign: 'center' },
  empty: { color: colors.dim, textAlign: 'center', marginTop: 20 },
  row2: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.panel,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginBottom: 6,
  },
  showName: { color: colors.text, fontSize: 13 },
  showCount: { color: colors.dim, fontSize: 12, fontFamily: 'monospace' },
});
