import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';

export default function EmptyState({ icon, text }: { icon: string; text: string }) {
  return (
    <View style={styles.wrap}>
      <Text style={styles.icon}>{icon}</Text>
      <Text style={styles.text}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 40, paddingBottom: 80 },
  icon: { fontSize: 40, marginBottom: 12, opacity: 0.5 },
  text: { color: colors.dim, fontSize: 13, textAlign: 'center', lineHeight: 20 },
});
