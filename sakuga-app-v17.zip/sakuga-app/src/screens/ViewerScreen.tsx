import React, { useState, useRef, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
import { useVideoPlayer, VideoView } from 'expo-video';
import { colors } from '../theme/colors';
import { isVideoFile, getTagTypeMap, fetchComments, formatCommentDate, Comment } from '../api/sakugabooru';
import { Ionicons } from '@expo/vector-icons';

// Same fps assumption as the bookmarklet: sakugabooru's post data doesn't
// expose a real frame rate, so this defaults to 24fps (standard for anime).
// Frame stepping is only as accurate as the player's own seek precision —
// same honest limitation as any browser-based approach, not something a
// native app magically fixes.
const DEFAULT_FPS = 24;
const MED_STEP = 10;

function formatTime(t: number) {
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  const sStr = s.toFixed(1).padStart(4, '0');
  return `${m}:${sStr}`;
}

export default function ViewerScreen({ route }: any) {
  const { post } = route.params;
  const playable = isVideoFile(post.file_url);
  const fps = Number(post.frame_rate) || DEFAULT_FPS;
  const bigStep = Math.max(1, Math.round(fps));

  const player = useVideoPlayer(playable ? post.file_url : null, (p) => {
    p.loop = false;
  });

  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  // expo-video doesn't guarantee a fine-grained timeupdate event across
  // platforms, so this polls the player's own position — simple and reliable
  // rather than depending on an event name I can't verify without testing.
  React.useEffect(() => {
    if (!playable) return;
    const interval = setInterval(() => {
      setCurrentTime(player.currentTime || 0);
      setDuration(player.duration || 0);
    }, 100);
    return () => clearInterval(interval);
  }, [playable, player]);

  const step = useCallback(
    (deltaFrames: number) => {
      player.pause();
      // Scrubbing mode only needs to be on for the instant of this seek —
      // turning it off again shortly after (rather than leaving it on) avoids
      // it interfering with a later native Play press.
      player.scrubbingModeOptions = { scrubbingModeEnabled: true };
      const next = currentTime + deltaFrames / fps;
      player.currentTime = Math.max(0, Math.min(duration || next, next));
      setTimeout(() => {
        player.scrubbingModeOptions = { scrubbingModeEnabled: false };
      }, 150);
    },
    [player, currentTime, duration, fps]
  );

  const frameCount = Math.round(currentTime * fps);
  const totalFrames = Math.round(duration * fps);

  const [artistTags, setArtistTags] = useState<string[]>([]);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [comments, setComments] = useState<Comment[] | null>(null);
  const [commentsLoading, setCommentsLoading] = useState(false);
  const [commentsError, setCommentsError] = useState<string | null>(null);

  const toggleComments = useCallback(() => {
    setCommentsOpen((open) => {
      const opening = !open;
      if (opening && comments === null && !commentsLoading) {
        setCommentsLoading(true);
        setCommentsError(null);
        fetchComments(post.id)
          .then(setComments)
          .catch((e) => setCommentsError(e.message || 'failed to load comments'))
          .finally(() => setCommentsLoading(false));
      }
      return opening;
    });
  }, [comments, commentsLoading, post.id]);
  const [otherTags, setOtherTags] = useState<string[]>((post.tags || '').split(/\s+/).filter(Boolean));

  useEffect(() => {
    let cancelled = false;
    getTagTypeMap()
      .then((map) => {
        if (cancelled) return;
        const all = (post.tags || '').split(/\s+/).filter(Boolean);
        setArtistTags(all.filter((t: string) => map[t] === 1));
        setOtherTags(all.filter((t: string) => map[t] !== 1));
      })
      .catch(() => {
        // Tag-type lookup failing isn't worth showing an error over — the
        // plain, unsplit tag list (already the initial state) is a fine fallback.
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.headRow}>
        <Text style={styles.badge}>▲ {post.score}</Text>
        <Text style={styles.badge}>{post.rating}</Text>
        <Text style={styles.postId}>#{post.id}</Text>
      </View>

      {playable ? (
        <>
          <VideoView player={player} style={styles.video} nativeControls />

          <View style={styles.frameBar}>
            <View style={styles.frameRow}>
              <TouchableOpacity style={styles.frameBtn} onPress={() => step(-bigStep)}>
                <Text style={styles.frameBtnText}>«</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.frameBtn} onPress={() => step(-MED_STEP)}>
                <Text style={styles.frameBtnText}>‹‹</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.frameBtn} onPress={() => step(-1)}>
                <Text style={styles.frameBtnText}>‹</Text>
              </TouchableOpacity>
              <Text style={styles.frameCount}>
                {frameCount} / {totalFrames}
              </Text>
              <TouchableOpacity style={styles.frameBtn} onPress={() => step(1)}>
                <Text style={styles.frameBtnText}>›</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.frameBtn} onPress={() => step(MED_STEP)}>
                <Text style={styles.frameBtnText}>››</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.frameBtn} onPress={() => step(bigStep)}>
                <Text style={styles.frameBtnText}>»</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.frameTime}>
              {formatTime(currentTime)} / {formatTime(duration)}
            </Text>
          </View>
        </>
      ) : (
        <Image
          source={{ uri: post.sample_url || post.file_url }}
          style={styles.image}
          resizeMode="contain"
        />
      )}

      <View style={styles.tagsSection}>
        {artistTags.length > 0 && (
          <>
            <Text style={styles.tagsLabel}>Animator</Text>
            <View style={styles.tagWrap}>
              {artistTags.map((t) => (
                <View key={t} style={styles.artistChip}>
                  <Text style={styles.artistChipText}>{t}</Text>
                </View>
              ))}
            </View>
          </>
        )}
        <Text style={styles.tagsLabel}>Tags</Text>
        <View style={styles.tagWrap}>
          {otherTags.map((t) => (
            <View key={t} style={styles.tagChip}>
              <Text style={styles.tagChipText}>{t}</Text>
            </View>
          ))}
        </View>
      </View>

      <TouchableOpacity style={styles.commentsToggle} onPress={toggleComments}>
        <Ionicons name="chatbubble-outline" size={14} color={colors.dim} />
        <Text style={styles.commentsToggleText}>
          {' '}
          Comments{comments ? ` (${comments.length})` : ''} {commentsOpen ? '▴' : '▾'}
        </Text>
      </TouchableOpacity>

      {commentsOpen && (
        <View style={styles.commentsPanel}>
          {commentsLoading && <ActivityIndicator color={colors.amber} style={{ marginVertical: 10 }} />}
          {commentsError && <Text style={styles.error}>error: {commentsError}</Text>}
          {comments && comments.length === 0 && !commentsLoading && (
            <Text style={styles.noComments}>no comments yet</Text>
          )}
          {comments &&
            comments.map((c) => {
              const name = c.creator || (c.creator_id ? `user #${c.creator_id}` : 'anonymous');
              const body = c.body || c.comment || '';
              const when = formatCommentDate(c.created_at);
              return (
                <View key={c.id} style={styles.comment}>
                  <View style={styles.commentHead}>
                    <Text style={styles.commentName}>{name}</Text>
                    {when ? <Text style={styles.commentDate}>{when}</Text> : null}
                  </View>
                  <Text style={styles.commentBody}>{body}</Text>
                </View>
              );
            })}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  headRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 10,
    backgroundColor: colors.panel2,
  },
  badge: {
    backgroundColor: colors.bg,
    color: colors.amber,
    fontSize: 11,
    fontFamily: 'monospace',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
    overflow: 'hidden',
  },
  postId: { color: colors.dim, fontSize: 11, fontFamily: 'monospace', marginLeft: 'auto' },
  video: { width: '100%', aspectRatio: 16 / 9, backgroundColor: '#000' },
  image: { width: '100%', height: 300, backgroundColor: '#000' },
  frameBar: { padding: 10, backgroundColor: colors.panel2 },
  frameRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  frameBtn: {
    backgroundColor: colors.bg,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 5,
    paddingHorizontal: 10,
    paddingVertical: 7,
  },
  frameBtnText: { color: colors.text, fontSize: 14 },
  frameCount: {
    flex: 1,
    textAlign: 'center',
    color: colors.amber,
    fontWeight: 'bold',
    fontFamily: 'monospace',
    fontSize: 13,
  },
  frameTime: {
    textAlign: 'center',
    color: colors.dim,
    fontFamily: 'monospace',
    fontSize: 11,
    marginTop: 6,
  },
  tagsSection: { padding: 16 },
  tagsLabel: { color: colors.text, fontSize: 12, fontWeight: 'bold', marginBottom: 8, marginTop: 6 },
  tagWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  artistChip: {
    backgroundColor: colors.amberDim,
    borderWidth: 1,
    borderColor: colors.amber,
    borderRadius: 14,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  artistChipText: { color: colors.amber, fontSize: 11, fontWeight: 'bold' },
  tagChip: {
    backgroundColor: colors.panel,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 14,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  tagChipText: { color: colors.dim, fontSize: 11 },
  commentsToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 16,
    marginBottom: 16,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: colors.line,
  },
  commentsToggleText: { color: colors.dim, fontSize: 12, fontWeight: '600' },
  commentsPanel: { paddingHorizontal: 16, paddingBottom: 24 },
  error: { color: colors.red, fontSize: 12, textAlign: 'center', marginVertical: 8 },
  noComments: { color: colors.dim, fontSize: 12, textAlign: 'center', marginVertical: 8 },
  comment: { paddingVertical: 10, borderTopWidth: 1, borderTopColor: colors.line },
  commentHead: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  commentName: { color: colors.amber, fontSize: 12, fontWeight: 'bold' },
  commentDate: { color: colors.dim, fontSize: 11 },
  commentBody: { color: colors.text, fontSize: 13, lineHeight: 19 },
});

