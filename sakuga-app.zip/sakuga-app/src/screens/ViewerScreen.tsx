import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { colors } from '../theme/colors';
import { isVideoFile } from '../api/sakugabooru';

// This is intentionally minimal for now — just proves navigation + real data
// flow works end to end. The frame-by-frame navigator, trim/download, tags
// breakdown, and comments (everything the bookmarklet's lightbox does) come
// next once this foundation is confirmed working on a real device.
export default function ViewerScreen({ route }: any) {
  const { post } = route.params;
  const playable = isVideoFile(post.file_url);

  return (
    <View style={styles.container}>
      <Text style={styles.meta}>
        ▲ {post.score} · {post.rating} · post #{post.id}
      </Text>
      {playable ? (
        <Text style={styles.note}>
          (video player goes here — post.file_url: {post.file_url})
        </Text>
      ) : (
        <Image source={{ uri: post.sample_url || post.file_url }} style={styles.image} resizeMode="contain" />
      )}
      <Text style={styles.tags}>{post.tags}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg, padding: 16 },
  meta: { color: colors.amber, fontFamily: 'monospace', marginBottom: 12 },
  note: { color: colors.dim, fontSize: 12 },
  image: { width: '100%', height: 300, backgroundColor: '#000' },
  tags: { color: colors.dim, fontSize: 11, marginTop: 16 },
});
