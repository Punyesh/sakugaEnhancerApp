import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { colors } from './src/theme/colors';
import SearchScreen from './src/screens/SearchScreen';
import ViewerScreen from './src/screens/ViewerScreen';

const Stack = createNativeStackNavigator();

const theme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: colors.bg,
    card: colors.panel2,
    text: colors.text,
    border: colors.line,
    primary: colors.amber,
  },
};

export default function App() {
  return (
    <NavigationContainer theme={theme}>
      <StatusBar style="light" />
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: colors.panel2 },
          headerTintColor: colors.amber,
          headerTitleStyle: { color: colors.text },
        }}
      >
        <Stack.Screen name="Search" component={SearchScreen} options={{ title: 'Sakuga' }} />
        <Stack.Screen name="Viewer" component={ViewerScreen} options={{ title: 'Clip' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
