import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Image,
  StyleSheet,
  ActivityIndicator,
  Pressable,
} from 'react-native';
import { colors } from '../theme/colors';
import { searchPosts, Post, isVideoFile, getTagTypeMap } from '../api/sakugabooru';
import ArtistStatsView from './ArtistStatsView';

type Order = 'score' | 'date' | 'random';
type Mode = 'results' | 'stats';

export default function SearchScreen({ navigation }: any) {
  const [mode, setMode] = useState<Mode>('results');
  const [tags, setTags] = useState<string[]>([]);
  const [pending, setPending] = useState('');
  const [order, setOrder] = useState<Order>('score');
  const [results, setResults] = useState<Post[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Whichever artist tag the current query is "about", if any — shown in the
  // Stats tab's label so the two feel connected. Kept separate from
  // statsSeedTag below since these two need different remount behavior.
  const [syncedArtist, setSyncedArtist] = useState<string | null>(null);
  // Only set when a *Results* search finds an artist tag — this is what
  // actually remounts/auto-triggers ArtistStatsView. Deliberately NOT updated
  // when the sync originates from Stats itself, since that view already just
  // fetched its own fresh data and remounting it would trigger a pointless
  // duplicate fetch of the same thing it already has.
  const [statsSeedTag, setStatsSeedTag] = useState<string | null>(null);

  const commitTag = useCallback(() => {
    const v = pending.trim().toLowerCase().replace(/\s+/g, '_');
    if (v) {
      setTags((t) => [...t, v]);
      setPending('');
    }
  }, [pending]);

  const removeTag = (i: number) => setTags((t) => t.filter((_, idx) => idx !== i));

  const performSearch = useCallback(
    async (tagsToUse: string[], syncToStats = true) => {
      setLoading(true);
      setError(null);
      try {
        const posts = await searchPosts(tagsToUse, order);
        setResults(posts);
        const typeMap = await getTagTypeMap();
        const artistTag = tagsToUse.find((t) => typeMap[t] === 1) || null;
        setSyncedArtist(artistTag);
        if (syncToStats) setStatsSeedTag(artistTag);
      } catch (e: any) {
        setError(e.message || 'search failed');
      } finally {
        setLoading(false);
      }
    },
    [order]
  );

  const runSearch = useCallback(() => {
    const finalTags = pending.trim() ? [...tags, pending.trim().toLowerCase().replace(/\s+/g, '_')] : tags;
    if (pending.trim()) {
      setTags(finalTags);
      setPending('');
    }
    performSearch(finalTags);
  }, [tags, pending, performSearch]);

  // A direct Stats lookup syncs back to Results: pre-fills the tag and re-runs
  // the search so switching tabs shows matching results without extra taps.
  // syncToStats=false here — Stats already has fresh data from its own
  // lookup, no need to remount/refetch it right back.
  const onStatsLookup = useCallback(
    (tag: string) => {
      setSyncedArtist(tag);
      setTags([tag]);
      performSearch([tag], false);
    },
    [performSearch]
  );

  return (
    <View style={styles.container}>
      <View style={styles.modeRow}>
        <TouchableOpacity
          style={[styles.modeBtn, mode === 'results' && styles.modeBtnActive]}
          onPress={() => setMode('results')}
        >
          <Text style={[styles.modeBtnText, mode === 'results' && styles.modeBtnTextActive]}>▤ Results</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.modeBtn, mode === 'stats' && styles.modeBtnActive]}
          onPress={() => setMode('stats')}
        >
          <Text style={[styles.modeBtnText, mode === 'stats' && styles.modeBtnTextActive]}>
            {syncedArtist ? `📊 Stats: ${syncedArtist}` : '📊 Animator Stats'}
          </Text>
        </TouchableOpacity>
      </View>

      {mode === 'stats' ? (
        <ArtistStatsView key={statsSeedTag || 'none'} initialTag={statsSeedTag || undefined} onLookupSuccess={onStatsLookup} />
      ) : (
        <>
          <View style={styles.row}>
            <TextInput
              style={styles.input}
              placeholder="add tag, then Search"
              placeholderTextColor={colors.dim}
              value={pending}
              onChangeText={setPending}
              onSubmitEditing={commitTag}
              returnKeyType="done"
            />
          </View>

          <View style={styles.orderRow}>
            {(['score', 'date', 'random'] as Order[]).map((o) => (
              <TouchableOpacity
                key={o}
                style={[styles.orderBtn, order === o && styles.orderBtnActive]}
                onPress={() => setOrder(o)}
              >
                <Text style={[styles.orderBtnText, order === o && styles.orderBtnTextActive]}>
                  {o === 'score' ? 'top score' : o === 'date' ? 'newest' : 'random'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {tags.length > 0 && (
            <View style={styles.chips}>
              {tags.map((t, i) => (
                <Pressable key={i} style={styles.chip} onPress={() => removeTag(i)}>
                  <Text style={styles.chipText}>{t} ×</Text>
                </Pressable>
              ))}
            </View>
          )}

          <TouchableOpacity style={styles.searchBtn} onPress={runSearch}>
            <Text style={styles.searchBtnText}>Search</Text>
          </TouchableOpacity>

          {loading && <ActivityIndicator color={colors.amber} style={{ marginTop: 20 }} />}
          {error && <Text style={styles.error}>error: {error}</Text>}

          {results && !loading && (
            <FlatList
              style={{ marginTop: 12 }}
              data={results}
              keyExtractor={(p) => String(p.id)}
              numColumns={3}
              columnWrapperStyle={{ gap: 6 }}
              contentContainerStyle={{ gap: 6 }}
              ListEmptyComponent={<Text style={styles.empty}>no posts matched those tags</Text>}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.card}
                  onPress={() => navigation.navigate('Viewer', { post: item })}
                >
                  <Image
                    source={{ uri: item.preview_url || item.jpeg_url || item.sample_url }}
                    style={styles.thumb}
                  />
                  {isVideoFile(item.file_url) && (
                    <View style={styles.vidmark}>
                      <Text style={styles.vidmarkText}>▶</Text>
                    </View>
                  )}
                  <View style={styles.score}>
                    <Text style={styles.scoreText}>▲ {item.score}</Text>
                  </View>
                </TouchableOpacity>
              )}
            />
          )}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg, padding: 12 },
  modeRow: { flexDirection: 'row', gap: 6, marginBottom: 10 },
  modeBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 6,
    paddingVertical: 8,
    alignItems: 'center',
  },
  modeBtnActive: { borderColor: colors.amber, backgroundColor: colors.amberDim },
  modeBtnText: { color: colors.dim, fontSize: 12, fontWeight: 'bold' },
  modeBtnTextActive: { color: colors.amber },
  row: { flexDirection: 'row', gap: 8, marginBottom: 8 },
  input: {
    flex: 1,
    backgroundColor: colors.panel,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 6,
    color: colors.text,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  orderRow: { flexDirection: 'row', gap: 6, marginBottom: 8 },
  orderBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 14,
    paddingVertical: 6,
    alignItems: 'center',
  },
  orderBtnActive: { borderColor: colors.amber, backgroundColor: colors.amberDim },
  orderBtnText: { color: colors.dim, fontSize: 12 },
  orderBtnTextActive: { color: colors.amber, fontWeight: 'bold' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 },
  chip: {
    backgroundColor: colors.panel,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 14,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  chipText: { color: colors.text, fontSize: 12 },
  searchBtn: {
    backgroundColor: colors.amberDim,
    borderWidth: 1,
    borderColor: colors.amber,
    borderRadius: 6,
    paddingVertical: 10,
    alignItems: 'center',
  },
  searchBtnText: { color: colors.amber, fontWeight: 'bold' },
  error: { color: colors.red, marginTop: 12, textAlign: 'center' },
  empty: { color: colors.dim, textAlign: 'center', marginTop: 20 },
  card: {
    flex: 1 / 3,
    aspectRatio: 1,
    backgroundColor: '#000',
    borderRadius: 4,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.line,
  },
  thumb: { width: '100%', height: '100%' },
  vidmark: {
    position: 'absolute',
    top: 3,
    left: 4,
    backgroundColor: 'rgba(0,0,0,0.7)',
    borderRadius: 8,
    paddingHorizontal: 4,
  },
  vidmarkText: { color: colors.text, fontSize: 9 },
  score: {
    position: 'absolute',
    top: 3,
    right: 4,
    backgroundColor: 'rgba(0,0,0,0.7)',
    borderRadius: 8,
    paddingHorizontal: 5,
  },
  scoreText: { color: colors.amber, fontSize: 10, fontFamily: 'monospace' },
});
